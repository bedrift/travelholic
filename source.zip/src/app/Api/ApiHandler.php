<?php

namespace App\Api;

use \Psr\Http\Message\{
    ServerRequestInterface as Request,
    ResponseInterface as Response
};

class ApiHandler {
    
}